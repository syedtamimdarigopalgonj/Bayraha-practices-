
#include <stdio.h>

int main()
{sc
  float add(int a,int b,int c){
      float sum =a+b+c;
      return sum;}

    return 0;
}
