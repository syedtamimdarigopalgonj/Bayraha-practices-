/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <string.h>

int main()
{
    int low = 1, high = 100000;

    // Taking the value of n as input and setting it as high as it will be the maximum value
    scanf("%d", &high);

    // To keep track of the number of tries
    int count = 0;

    // Binary search
    while (low <= high)
    {
        // Finding the mid value
        int mid = (low + high) >> 1;

        // Printing the guess
        printf("guess %d\n", mid);

        // Taking the response as input
        char response[10];
        scanf("%s", response);

        // Checking the response
        if (strcmp(response, "correct") == 0)
            return 0;
        else if (strcmp(response, "high") == 0)
            high = mid - 1;
        else if (strcmp(response, "low") == 0)
            low = mid + 1;

        // Increasing the count
        count++;

        // If the count is greater than 30 then printing too many tries and returning
        if (count >= 30)
        {
            printf("too many tries\n");
            return 0;
        }
    }

    return 0;
}