/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <ctype.h>
#include <stdio.h>
#include <string.h>

// Points assigned to each letter of the alphabet
int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int compute_score(const char *word);

int main(void)
{
    // Get input words from both players
    char word1[50];
    char word2[50];

    printf("Player 1: ");
    scanf("%s", word1);

    printf("Player 2: ");
    scanf("%s", word2);

    // Score both words
    int score1 = compute_score(word1);
    int score2 = compute_score(word2);

    // Print the scores
    printf("Player 1 Score: %d\n", score1);
    printf("Player 2 Score: %d\n", score2);

    // Determine the winner
    if (score1 > score2)
    {
        printf("Player 1 wins!\n");
    }
    else if (score1 < score2)
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("It's a tie!\n");
    }

    return 0;
}

int compute_score(const char *word)
{
    int score = 0;

    // Iterate through each character in the word
    for (int i = 0, n = strlen(word); i < n; i++)
    {
        // Convert the character to uppercase
        char c = toupper(word[i]);

        // Check if it's an uppercase letter
        if (isalpha(c))
        {
            // Calculate the index in the POINTS array
            int index = c - 'A';

            // Add the corresponding score to the total score
            score += POINTS[index];
        }
    }

    return score;
}
