/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int a,b,c;
int sum,sub,multi;
    printf("Enter two intiger number:");
    scanf("%d %d %d",&a,&b,&c);
sum=a+b+c;
sub=a-b;
multi=a*b*c;
printf("%d",sum);
    return 0;
}
